import { Doctor, Appointment, Prescription } from '../types';

export const mockDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    specialty: 'Cardiology',
    rating: 4.9,
    experience: 12
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    specialty: 'Dermatology',
    rating: 4.8,
    experience: 8
  },
  {
    id: '3',
    name: 'Dr. Emily Rodriguez',
    specialty: 'Pediatrics',
    rating: 4.9,
    experience: 15
  },
  {
    id: '4',
    name: 'Dr. David Thompson',
    specialty: 'Orthopedics',
    rating: 4.7,
    experience: 10
  },
  {
    id: '5',
    name: 'Dr. Lisa Anderson',
    specialty: 'Neurology',
    rating: 4.8,
    experience: 14
  }
];

export const mockAppointments: Appointment[] = [
  {
    id: '1',
    patientId: 'user1',
    patientName: 'John Doe',
    doctorId: '1',
    doctorName: 'Dr. Sarah Johnson',
    specialty: 'Cardiology',
    date: '2024-01-15',
    time: '10:00 AM',
    status: 'scheduled',
    notes: 'Regular checkup'
  },
  {
    id: '2',
    patientId: 'user1',
    patientName: 'John Doe',
    doctorId: '3',
    doctorName: 'Dr. Emily Rodriguez',
    specialty: 'Pediatrics',
    date: '2024-01-20',
    time: '2:30 PM',
    status: 'completed',
    notes: 'Follow-up consultation'
  },
  {
    id: '3',
    patientId: 'user2',
    patientName: 'Jane Smith',
    doctorId: '2',
    doctorName: 'Dr. Michael Chen',
    specialty: 'Dermatology',
    date: '2024-01-25',
    time: '11:15 AM',
    status: 'scheduled',
    notes: 'Skin consultation'
  }
];

export const mockPrescriptions: Prescription[] = [
  {
    id: '1',
    patientId: 'user1',
    doctorId: '1',
    doctorName: 'Dr. Sarah Johnson',
    date: '2024-01-10',
    medications: [
      {
        id: '1',
        name: 'Lisinopril',
        dosage: '10mg',
        frequency: 'Once daily',
        duration: '30 days'
      },
      {
        id: '2',
        name: 'Metformin',
        dosage: '500mg',
        frequency: 'Twice daily',
        duration: '30 days'
      }
    ],
    instructions: 'Take medications with food. Monitor blood pressure daily.'
  },
  {
    id: '2',
    patientId: 'user1',
    doctorId: '3',
    doctorName: 'Dr. Emily Rodriguez',
    date: '2024-01-05',
    medications: [
      {
        id: '3',
        name: 'Amoxicillin',
        dosage: '250mg',
        frequency: 'Three times daily',
        duration: '7 days'
      }
    ],
    instructions: 'Complete the full course of antibiotics even if symptoms improve.'
  }
];

export const timeSlots = [
  '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
  '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM', '4:00 PM', '4:30 PM'
];