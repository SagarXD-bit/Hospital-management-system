import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Calendar, 
  FileText, 
  Stethoscope, 
  Users, 
  Clock, 
  Shield,
  Heart,
  ArrowRight
} from 'lucide-react';

const HomePage: React.FC = () => {
  const features = [
    {
      icon: Calendar,
      title: 'Easy Appointment Booking',
      description: 'Schedule appointments with your preferred doctors at convenient times.',
      link: '/book-appointment'
    },
    {
      icon: Stethoscope,
      title: 'Track Your Health',
      description: 'Monitor your medical history and upcoming appointments in one place.',
      link: '/appointments'
    },
    {
      icon: FileText,
      title: 'Digital Prescriptions',
      description: 'Access and manage your prescriptions digitally with detailed instructions.',
      link: '/prescriptions'
    },
    {
      icon: Users,
      title: 'Expert Doctors',
      description: 'Connect with qualified healthcare professionals across various specialties.',
      link: '/book-appointment'
    }
  ];

  const stats = [
    { icon: Users, value: '500+', label: 'Qualified Doctors' },
    { icon: Calendar, value: '10K+', label: 'Appointments Booked' },
    { icon: Heart, value: '25K+', label: 'Happy Patients' },
    { icon: Clock, value: '24/7', label: 'Support Available' }
  ];

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 rounded-2xl overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative px-6 py-16 sm:px-12 sm:py-20 lg:px-16">
          <div className="max-w-3xl">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight">
              Your Health,
              <span className="block text-blue-200">Our Priority</span>
            </h1>
            <p className="mt-6 text-xl text-blue-100 leading-relaxed">
              Manage your healthcare journey with ease. Book appointments, track medications, 
              and stay connected with your healthcare providers all in one secure platform.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              <Link
                to="/register"
                className="inline-flex items-center justify-center px-8 py-4 bg-white text-blue-600 font-semibold rounded-lg hover:bg-blue-50 transition-colors duration-200 shadow-lg"
              >
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link
                to="/book-appointment"
                className="inline-flex items-center justify-center px-8 py-4 border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-blue-600 transition-colors duration-200"
              >
                Book Appointment
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-lg text-center hover:shadow-xl transition-shadow duration-200">
              <Icon className="h-8 w-8 text-blue-600 mx-auto mb-3" />
              <div className="text-3xl font-bold text-gray-900">{stat.value}</div>
              <div className="text-gray-600 font-medium">{stat.label}</div>
            </div>
          );
        })}
      </section>

      {/* Features Section */}
      <section>
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Why Choose HealthTrack?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Experience healthcare management like never before with our comprehensive platform 
            designed to put you in control of your health journey.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 group">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center group-hover:bg-blue-600 transition-colors duration-200">
                      <Icon className="h-6 w-6 text-blue-600 group-hover:text-white" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-gray-600 mb-4 leading-relaxed">
                      {feature.description}
                    </p>
                    <Link
                      to={feature.link}
                      className="inline-flex items-center text-blue-600 font-medium hover:text-blue-700 transition-colors duration-200"
                    >
                      Learn more
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Security Section */}
      <section className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-8 sm:p-12">
        <div className="flex flex-col lg:flex-row items-center space-y-6 lg:space-y-0 lg:space-x-8">
          <div className="flex-shrink-0">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <Shield className="h-8 w-8 text-green-600" />
            </div>
          </div>
          <div className="flex-1 text-center lg:text-left">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">
              Your Data is Secure
            </h3>
            <p className="text-gray-600 leading-relaxed">
              We use industry-standard encryption and security measures to protect your personal 
              health information. Your privacy and security are our top priorities.
            </p>
          </div>
          <div className="flex-shrink-0">
            <Link
              to="/register"
              className="inline-flex items-center px-6 py-3 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors duration-200"
            >
              Join Now
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;