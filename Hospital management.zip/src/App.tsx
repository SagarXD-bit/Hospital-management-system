import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import RegisterPage from './pages/RegisterPage';
import LoginPage from './pages/LoginPage';
import AppointmentBookingPage from './pages/AppointmentBookingPage';
import ViewAppointmentsPage from './pages/ViewAppointmentsPage';
import PrescriptionPage from './pages/PrescriptionPage';

function App() {
  return (
    <Router>
      <Routes>
        {/* Pages with Layout */}
        <Route path="/" element={<Layout><HomePage /></Layout>} />
        <Route path="/book-appointment" element={<Layout><AppointmentBookingPage /></Layout>} />
        <Route path="/appointments" element={<Layout><ViewAppointmentsPage /></Layout>} />
        <Route path="/prescriptions" element={<Layout><PrescriptionPage /></Layout>} />
        
        {/* Full-screen pages without Layout */}
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/login" element={<LoginPage />} />
      </Routes>
    </Router>
  );
}

export default App;